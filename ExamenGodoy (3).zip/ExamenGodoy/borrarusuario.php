<?php
session_start(); 

if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
    header('Location: login.php');
    exit;
}

include('conexion.ini.php');
$conectar = new Conexion('localhost', 'root', '', 'discografia');
$conexion = $conectar->conectionPDO();

// Comprobación de si el usuario es admin o no
$esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

if ($esAdmin) {
    include_once('header_root.inc.php');
} else {
    include_once('header_publico.inc.php');
}

$id = $_GET['id'];

if (isset($_POST['confirmar_si'])) {
    try {
        $eliminar_consulta = $conexion->prepare('DELETE FROM tabla_usuarios where id= ?');
        $eliminar_consulta->execute([$id]); 

        header('Location: usuarios.php?msg=Usuario+Eliminado+Correctamente');
        exit();
    } catch (Exception $e) {
        echo '<h1 id="mal">ERROR AL Eliminar el Usuario!</h1>';
        echo $e;
    }
} elseif (isset($_POST['confirmar_no'])) {
    header('Location: usuarios.php');
    exit();
} else {
    // SOLO mostrar el formulario si NO se ha hecho clic aún
    try {
        
        $nombre_consulta = $conexion->prepare('SELECT usuario from tabla_usuarios where id = ? AND usuario NOT LIKE "%admin%"');
        $nombre_consulta->execute([$id]);
        $resultado = $nombre_consulta->fetch(PDO::FETCH_ASSOC); // ✅ Obtener array asociativo
        
        // VERIFICAR si se encontró el usuario
        if ($resultado && isset($resultado['usuario'])) {
            $nombre = $resultado['usuario'];
            
            echo '<h1>Eliminar Usuario</h1>';
            echo '<form action="" method="post">';
            echo '<h3>¿Seguro que quieres eliminar a ' . htmlspecialchars($nombre) . '?</h3>'; 
            echo '<button type="submit" name="confirmar_si">Sí</button>';
            echo '<button type="submit" name="confirmar_no">No</button>';
            echo '</form>';
            
        } else {
            echo '<h1 id="mal">Usuario no encontrado o no se puede eliminar (es admin)</h1>';
            echo '<button onclick="location.href=\'usuarios.php\'">Volver</button>';
        }
        
    } catch (Exception $e) {
        echo '<h1 id="mal">ERROR AL RECOGER AL USUARIO!</h1>';
        echo $e;
        echo '<button onclick="location.href=\'usuarios.php\'">Volver</button>';
    }
}
?>