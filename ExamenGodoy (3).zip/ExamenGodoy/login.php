<?php
require_once 'helper.php';
include("conexion.ini.php");
session_start();
$conectar = new Conexion('localhost', 'root', '', 'discografia');
$conexion = $conectar->conectionPDO();

// Si ya está autenticado, redirigir a index
if (isset($_SESSION['autenticado']) && $_SESSION['autenticado'] === true) {
    header('Location: index.php');
    exit();
}

// Verificar cookie de "recordar"
if (isset($_COOKIE['usuario']) && !isset($_POST['enviar']) && !isset($_POST['confirmar_si']) && !isset($_POST['confirmar_no'])) {
    $usuario_recordado = $_COOKIE['usuario'];
    
    // Mostrar confirmación de autenticación rápida
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
    </head>
    <body>
        <h1>¿Quieres iniciar sesión como <?php echo htmlspecialchars($usuario_recordado); ?>?</h1>
        <form action="login.php" method="post">  
            <input type="hidden" name="usuario" value="<?php echo $usuario_recordado; ?>">
            <button type="submit" name="confirmar_si">Sí</button>
            <button type="submit" name="confirmar_no">No</button>
        </form>
    </body>
    </html>
    <?php
    exit(); //exit() evita que se siga ejecutando el resto del código y se muestre el formulario normal.
}

//Procesar confirmación de cookie "SÍ"
if (isset($_POST['confirmar_si']) && isset($_POST['usuario'])) {
    $usuario = $_POST['usuario'];
    
    // Buscar usuario en la base de datos para obtener ID
    $consulta = $conexion->prepare('SELECT id, usuario FROM tabla_usuarios WHERE usuario=?');
    $consulta->execute([$usuario]);
    $resultado = $consulta->fetch(PDO::FETCH_ASSOC);
    
    if ($resultado) {
        $_SESSION['autenticado'] = true;
        $_SESSION['id_user'] = $resultado['id'];
        $_SESSION['username'] = $resultado['usuario'];
        header('Location: index.php');
        exit();

    } else {
        //Si el usuario de la cookie no existe en BD, eliminar cookie y mostrar formulario
        setcookie('usuario', '', time() - 3600, '/');
    }
}

// Procesar confirmación "NO, se elimina la cookie e irá al formulario login normal, 
//no pasará por if (isset($_COOKIE['usuario_recordado']) && !isset($_POST['enviar']) && !isset($_POST['confirmar_si']) && !isset($_POST['confirmar_no'])) 
if (isset($_POST['confirmar_no'])) {
    setcookie('usuario', '', time() - 3600, '/');
    // Recargar la página para mostrar formulario normal
    header('Location: login.php');
    exit();
}

// Procesar login normal
if (isset($_POST['enviar'])) {
    try {
        if (trim($_POST['pass']) == '' || trim($_POST['user']) == '') {
            throw new PDOException('Debes rellenar ambos campos!');
        } else {
            $contraseña = trim($_POST['pass']);
            $usuario = trim($_POST['user']);
            $consulta = $conexion->prepare('SELECT password, id, usuario FROM tabla_usuarios WHERE usuario=?');
            $consulta->execute([$usuario]);
            $resultado = $consulta->fetch(PDO::FETCH_ASSOC);

            // Comprobamos que coincidan la contraseña introducida con la obtenida
            if ($resultado && password_verify($contraseña, $resultado['password'])) {
                $_SESSION['autenticado'] = true;
                $_SESSION['id_user'] = $resultado['id'];
                $_SESSION['username'] = $resultado['usuario'];

                if($usuario == 'root' || $usuario == 'admin'){
                    $_SESSION['admin'] = 'si';
                }else{
                      $_SESSION['admin'] = 'no';
                }
                
                //Crea la cookie 'usuario'
                setcookie('usuario', $usuario, time() + (30 * 24 * 60 * 60), '/'); // 30 días
                
                header('Location: index.php');
                exit();
            } else {
                $_SESSION['autenticado'] = false;
                throw new PDOException('Los datos son incorrectos!');
            }
        }
    } catch (PDOException $e) {
        echo '<p style="color:red;">ERROR: ' . $e->getMessage() . '</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Bienvenido de nuevo!</h1>
    <form action="login.php" method="post">  
        <label for="usuario">Introduce tu usuario:</label>
        <input type="text" name="user" id="usuario">
        <br><br>
        <label for="contraseña">Introduce tu contraseña:</label>
        <input type="password" name="pass" id="contraseña">
        <br><br>
        <input type="submit" value="enviar" name="enviar">
    </form>
    <p>Ir a <a href="registro.php">Registro</a></p>
</body>
</html>