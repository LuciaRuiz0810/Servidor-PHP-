<?php
require_once 'helper.php';
include("conexion.ini.php");
session_start(); // IMPORTANTE: Iniciar sesión

$conectar = new Conexion('localhost', 'root', '', 'discografia');
$conexion = $conectar->conectionPDO();

if (isset($_POST['enviar'])) {

    try {
        // Validación de campos vacíos
        if (trim($_POST['pass']) == '' || trim($_POST['user']) == '') {
            throw new PDOException('Debes rellenar ambos campos!');
        }
        
        $contraseña = trim($_POST['pass']);
        $usuario = trim($_POST['user']);
        $hash = password_hash($contraseña, PASSWORD_DEFAULT);

        // Insertar usuario en la base de datos
        $consulta = $conexion->prepare('INSERT INTO tabla_usuarios(usuario, password) VALUES (?, ?)');
        $consulta->execute([$usuario, $hash]);

        $idUsuario = $conexion->lastInsertId();

        if (!$consulta) {
            throw new PDOException('Fallo al insertar en la base de datos!');
        }

        // PROCESAMIENTO DE IMAGEN SOLO SI SE SUBIÓ UN ARCHIVO
        if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] !== UPLOAD_ERR_NO_FILE) {
            
            // Manejo de errores en la subida del archivo
            switch ($_FILES['archivo']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('El archivo excede el tamaño permitido');
                default:
                    throw new RuntimeException('Error desconocido al subir archivo');
            }

            // Control de ataques
            if (!is_uploaded_file($_FILES['archivo']['tmp_name'])) {
                throw new RuntimeException('Posible ataque: archivo no válido');
            }

            // Obtenemos el nombre del archivo
            $archivo = $_FILES['archivo']['tmp_name'];
            // Obtenemos el tipo de archivo
            $tipo = $_FILES['archivo']['type'];
            // Obtenemos las medidas
            list($ancho, $alto) = getimagesize($archivo);

            // Comprobación de que el archivo es png o jpg
            if ($tipo != 'image/png' && $tipo != 'image/jpg' && $tipo != 'image/jpeg') {
                throw new RuntimeException('Error: Solo se permiten archivos PNG o JPG');
            }

            // Comprobar que cumple con el tamaño
            if ($ancho > 360 || $alto > 480) {
                throw new RuntimeException('La imagen supera el tamaño máximo de 360x480px');
            }

            // Crear la imagen jpeg o png
            if ($tipo == 'image/jpeg' || $tipo == 'image/jpg') {
                $imagenOriginal = imagecreatefromjpeg($archivo);
            } else if ($tipo == 'image/png') {
                $imagenOriginal = imagecreatefrompng($archivo);
            }

            // Creación imagen grande 360 x 480
            $imagenGrande = imagecreatetruecolor(360, 480);
            imagecopyresampled($imagenGrande, $imagenOriginal, 0, 0, 0, 0, 360, 480, $ancho, $alto);

            // Creación imagen pequeña 72 x 96
            $imagenPeque = imagecreatetruecolor(72, 96);
            imagecopyresampled($imagenPeque, $imagenOriginal, 0, 0, 0, 0, 72, 96, $ancho, $alto);

            // Usamos el ID del usuario recién creado
            $username = $usuario;

            // Creación ruta
            $ruta = __DIR__ . "/img/users/{$username}";
            if (!is_dir($ruta)) {
                mkdir($ruta, 0777, true);
            }

            // Guardamos las imagenes en las rutas correspondientes
            $ruta_big = "$ruta/{$idUsuario}Big.png";
            $ruta_small = "$ruta/{$idUsuario}Small.png";

            // Guardamos las imágenes en la ruta incluyendo el id del usuario
            imagepng($imagenGrande, $ruta_big);
            imagepng($imagenPeque, $ruta_small);

            // Guardamos las rutas en tabla_usuarios
            $consulta = $conexion->prepare('UPDATE tabla_usuarios SET url_big = ?, url_small = ? WHERE id = ?');
            $consulta->execute(["img/users/$username/{$idUsuario}Big.png", "img/users/$username/{$idUsuario}Small.png", $idUsuario]);

            // Si falla se lanza una excepción
            if (!$consulta) {
                throw new PDOException('Fallo al añadirla a la base de datos!');
            }

            // Liberamos la memoria 
            imagedestroy($imagenOriginal);
            imagedestroy($imagenGrande);
            imagedestroy($imagenPeque);
        }

        // Redirigimos al login después de todo el proceso
        header('Location: login.php');
        exit();

    } catch (PDOException $e) {
        echo '<p style="color:red;">ERROR: ' . $e->getMessage() . '</p>';
    } catch (RuntimeException $e) {
        echo '<p style="color:red;">ERROR: ' . $e->getMessage() . '</p>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>

<body>
    <h1>Página de registro</h1>
    <form action="#" method="post" enctype="multipart/form-data">
        <label for="usuario">Introduce tu usuario:</label>
        <input type="text" name="user" id="usuario" required>
        <br><br>
        <label for="contraseña">Introduce tu contraseña:</label>
        <input type="password" name="pass" id="contraseña" required>
        <br><br>
        <label>Seleccionar imagen (opcional):</label>
        <input type="file" name="archivo">
        <br><br>
        <input type="submit" value="enviar" name="enviar">
    </form>
    <br><br>
    <p>Ir a <a href="login.php">Login</a></p>
</body>

</html>