<!-- HEADER PÚBLICO (sin sesión, para login / registro / portada) -->
<header style="background:#333; padding:15px;">
    <nav style="display:flex; gap:20px;">
        <a href="index.php" style="color:white; text-decoration:none;">Inicio</a>
        <a href="registro.php" style="color:white; text-decoration:none;">Registro</a>
        <a href="login.php" style="color:white; text-decoration:none;">Iniciar sesión</a>
    </nav>
</header>
