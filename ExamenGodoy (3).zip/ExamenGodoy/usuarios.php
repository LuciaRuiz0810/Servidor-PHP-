<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    session_start();
    if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
        header('Location: login.php');
        exit;
    }
    include("datos.ini.php");
    include("conexion.ini.php");

    //Comprobación de si el usurio es admin o no
    $esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

    if ($esAdmin) {
        include_once('header_root.inc.php');
    } else {
        include_once('header_publico.inc.php');
    }


    if (isset($_GET['msg'])) {
        $msg = $_GET['msg'];
        echo "<div><p style=  color:green>" . $msg . "</p></div>";
    }

    listaUsuarios();
    ?>
</body>

</html>