<?php
require_once 'helper.php';
session_start();
  
$user_nombre =$_SESSION['username'];
$user_id = $_SESSION['id_user'];
$ruta = "img/users/{$user_nombre}";
echo "<div style=text-align:center><img src='$ruta/{$user_id}Big.png' alt='imgPerfil'</div> ";
echo "<h3 style=text-align:center>Nombre de Usuario: $user_nombre</h3>";

     if (isset($_GET['msg'])) {
		$msg = $_GET['msg'];
		echo "<div><p style=  color:green>" . $msg . "</p></div>";
	}

echo "<a href='cambiarImagen.php?id=$user_id'>Actualizar Imagen</a>";
echo '<br>';
echo "<a href='cambiarContraseña.php?id=$user_id'>Cambiar Contraseña</a>";
echo '<br>';
echo "<a href='index.php'>Volver al inicio</a>";

?>