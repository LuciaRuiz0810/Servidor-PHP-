<?php
require_once 'helper.php';
function formularioDisco()
{ //Esta función imprimirá en la página un formulario y llamará a la función registrar del objeto para registrar un disco nuevo
	echo '<button  onclick=location.href="./index.php">Volver</button>';
	echo '<h1>Crear nuevo disco</h1>';
	echo '<form action="disconuevo.php" method="post">';
	echo '<input type="text" required name="titulo" placeholder="Título"/>';
	echo '<input type="text" required name="discografia" placeholder="Discografía"/>';
	echo '<label>formato: </label>';
	echo '<select name="formato">
			<option> vinilo</option>
			<option> cd</option>
			<option> dvd</option>
			<option> mp3</option>
			</select>';
	echo '<label>fechaLanzamiento: </label>';
	echo '<input type="date" name="fechaLanzamiento"/>';
	echo '<label>fechaCompra: </label>';
	echo '<input type="date" name="fechaCompra"/>';
	echo '<input type="number" step="  " min=0 value=0 name="precio" placeholder="precio"/>';
	echo '<input id="reg-mod" type="submit" value="Registrar"/>';
	echo '</form>';

	//Si titulo contiene texto (obligatorio) se podrá insertar el disco en la bbdd
	//ALTERNATIVA: manejar el registro a través del boton registrar y dentro hacer las validaciones de que los campos
	// obligatorios estén completos
	if (isset($_POST["titulo"])) {
		$conectar = new Conexion('localhost', 'root', '', 'discografia');
		$conexion = $conectar->conectionPDO();
		$album = new Album('', $_POST['titulo'], $_POST['discografia'], $_POST['formato'], $_POST['fechaLanzamiento'], $_POST['fechaCompra'], $_POST['precio']);

		$album->registrarDisco($conexion);
	}
}

function formularioCancion($cancion)
{ //Esta función imprimirá en la página un formulario y llamará a la función registrar del objeto para registrar una cancion nueva
	echo '<button  onclick=location.href="./index.php">Volver</button>';
	echo '<h1>Crear nueva canción</h1>';
	echo '<form action="cancionnueva.php?cod=' . $cancion->getAlbum() . '&titulo=' . $cancion->getTitulo() . '" method="post">';
	echo '<input type="text" required name="titulo" placeholder="Título" />';
	echo '<label>Album: </label>';
	echo '<input type="text" required name="album" value="' . $cancion->getTitulo() . '" readonly/>';
	echo '<label>Posición: </label>';
	echo '<input type="number" min=0 name="posicion" value=0 />';
	echo '<label>Duración: </label>';
	echo '<input type="time" name="duracion" step="1"/>';
	echo '<label>Género: </label>';
	echo '<select name="genero">
			<option> Acustica</option>
			<option> BSO</option>
			<option> Blues</option>
			<option> Folk</option>
			<option> Jazz</option>
			<option> New age</option>
			<option> Pop</option>
			<option> Rock</option>
			<option> Electronica</option>
			</select>';
	echo '<input id="reg-mod" type="submit" value="Registrar"/>';
	echo '</form>';

	//Igual que FormularioDisco
	if (isset($_POST["titulo"])) {
		$conectar = new Conexion('localhost', 'root', '', 'discografia');
		$conexion = $conectar->conectionPDO();
		$cancion = new Cancion($_POST['titulo'], $cancion->getAlbum(), $_POST['posicion'], $_POST['duracion'], $_POST['genero']);
		$cancion->registrarCancion($conexion);
	}
}

function formularioBuscarCancion()

{ //Esta función imprimirá en la página un formulario y llamará a la función datosBuacados para devolver una lista de canciones



	echo '<button  onclick=location.href="./index.php">Volver</button>';
	echo '<h1>Búsqueda de canciones</h1>';
	echo '<form action="canciones.php" method="post">';
	echo 'Texto a buscar: ';
	echo '<input type="text" required name="textoBuscar" list="busquedas-anteriores"/>';
	echo '<datalist id="busquedas-anteriores">';


    $busquedas = gestionarCookieBusqueda(''); // Pasamos vacío para solo obtener las existentes

	//Las recorremos y mostramos en el datalist
    foreach ($busquedas as $busqueda) {
        echo ' <option value="' . htmlspecialchars($busqueda) . '">';
    }
	echo	'</datalist>';

	echo '<div>';
	echo 'Buscar en: ';
	echo '<input type="radio" id=tc name="select" checked value="cancion.titulo"/>';
	echo '<label for="tc">Títulos de canción </label>';
	echo '<input type="radio" id="na" name="select" value="album.titulo"/>';
	echo '<label for="na">Nombres álbum </label>';
	echo '<input type="radio" id="ca" name="select" value="album.titulo = cancion.titulo and cancion.titulo"/>';
	echo '<label for="ca">Ambos campos </label>';
	echo '</div>';
	echo '<div>';
	echo 'Genero musical: ';
	echo '<select name="genero">
		<option> Acustica</option>
		<option> BSO</option>
		<option> Blues</option>
		<option> Folk</option>
		<option> Jazz</option>
		<option> New age</option>
		<option> Pop</option>
		<option> Rock</option>
		<option> Electronica</option>
		</select>';
	echo '</div>';
	echo '<input id="reg-mod" type="submit" value="Buscar"/>';
	echo '</form>';
	//si el input contiene texto:
	if (isset($_POST["textoBuscar"])) {

		//Añadimos la cookie
		gestionarCookieBusqueda($_POST['textoBuscar']);
		//se llama a datosBuscados pasandole el contenido del formulario (name)
		datosBuscados($_POST['textoBuscar'], $_POST['select'], $_POST['genero']);

		//registrarDisco($_POST['titulo'],$_POST['discografia'],$_POST['formato'],$_POST['fechaLanzamiento'],$_POST['fechaCompra'],$_POST['precio']);
	}
}

//Función que imprime los los albumes en una lista  
function datosDiscografia()
{ //devuelve una lista de Albums
	$conectar = new Conexion('localhost', 'root', '', 'discografia');
	$conexion = $conectar->conectionPDO();

	//Consulta que recoge todos los albums
	$resultado = $conexion->query('SELECT codigo,titulo,discografica,formato,fechaLanzamiento,fechaCompra,precio FROM discografia.album;');
	//Botones para buscar canciones o añadir un nuevo disco
	echo '<button  onclick=location.href="./disconuevo.php">Nuevo disco</button>';
	echo '<button  onclick=location.href="./canciones.php">Buscar canciones</button>';
	echo '<table>';
	echo '<tr>
			<th>título</th>
			<th>Discografía</th>
			<th>formato</th>
			<th>fechaLanzamiento</th>
			<th>fechaCompra</th>
			<th>Precio</th>			
		</tr>';
	//Mientras que la consulta almacenada en $resultado tenga valores, se iran imprimiendo
	while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)) {

		//Se crea el nuevo album obtenido de la lista para luego poder usar getters y setters
		$album = new Album($registro['codigo'], $registro['titulo'], $registro['discografica'], $registro['formato'], $registro['fechaLanzamiento'], $registro['fechaCompra'], $registro['precio']);
		echo '<tr>';

		//Crea el titulo con el enlace al que le pasa el codigo
		echo '<td><a href="disco.php?cod=' . $album->getCod() . '">' . $album->getTitulo() . '</a></td>';

		//Se imprimen el resto de campos
		echo '<td>' . $album->getDiscografia() . '</td>';
		echo '<td>' . $album->getFormato() . '</td>';
		echo '<td>' . $album->getFechaL() . '</td>';
		echo '<td>' . $album->getFechaC() . '</td>';
		echo '<td>' . $album->getPrecio() . '</td>';

		//Boton para cancion nueva a la que le passamos el codigo del album correcto y el titulo para luego usarlo
		//dentro de cancionnueva.php
		echo '<th id="botonInsertar"><button onclick="location.href=\'./cancionnueva.php?cod=' . $album->getCod() . '&titulo=' . urlencode($album->getTitulo()) . '\'">Canción Nueva</button></th>';
		echo '<th id="botonInsertar"><button onclick="location.href=\'./EditarDisco.php?cod=' . $album->getCod() . '&titulo=' . urlencode($album->getTitulo()) . '\'">Editar Disco</button></th>';
		echo '</tr>';
	}
	echo '</table>';
}

//Función para mostrar las canciones de los albums
function datosDisco($album)
{ //Devuelve los datos del album seleccionado
	$conectar = new Conexion('localhost', 'root', '', 'discografia');
	$conexion = $conectar->conectionPDO();

	//Consulta que devuelve el total de canciones 
	$resultado = $conexion->query('SELECT count(titulo) as totalCanciones FROM discografia.cancion WHERE cancion.album = ' . $album->getCod() . ';');
	while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)) {
		$TC = $registro['totalCanciones'];
	}
	//Consulta que devuelve la información del disco
	//igual que en datosDiscografia, pero solo ese disco (filtra por el codigo del $album pasado)
	$resultado = $conexion->query('SELECT codigo,titulo,discografica,formato,fechaLanzamiento,fechaCompra,precio FROM discografia.album WHERE album.codigo = ' . $album->getCod() . ';');

	//Botón para volver al index
	echo '<button  onclick=location.href="./index.php">Volver</button>';
	//Tabla de DATOS DEL DISCO
	echo '<h1>DATOS DEL DISCO</h1>';
	echo '<table>';
	echo '<tr>
			<th>Código</th>
			<th>título</th>
			<th>Discografía</th>
			<th>formato</th>
			<th>fechaLanzamiento</th>
			<th>fechaCompra</th>
			<th>Precio</th>			
		</tr>';

	//Muestra la información del disco a través del resultado de la consulta ($resultado)
	while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)) {
		//Crea el album con las campos para luego poder imprimir la información
		//ALTERNATIVA: eliminar new album y usar directamente en td $registro['codigo'], $registro['titulo']....
		$listaAlbum = new Album($registro['codigo'], $registro['titulo'], $registro['discografica'], $registro['formato'], $registro['fechaLanzamiento'], $registro['fechaCompra'], $registro['precio']);
		echo '<tr>';
		echo '<td>' . $listaAlbum->getCod() . '</td>';
		echo '<td>' . $listaAlbum->getTitulo() . '</td>';
		echo '<td>' . $listaAlbum->getDiscografia() . '</td>';
		echo '<td>' . $listaAlbum->getFormato() . '</td>';
		echo '<td>' . $listaAlbum->getFechaL() . '</td>';
		echo '<td>' . $listaAlbum->getFechaC() . '</td>';
		echo '<td>' . $listaAlbum->getPrecio() . '</td>';
		//botón para borrar el disco
		//se le pasa el codigo del album y el total canciones TC
		echo '<th id="botonBorrar" ><button  onclick=location.href="./borrardisco.php?cod=' . $album->getCod() . '&TC=' . $TC . '">Borrar disco</button></th>';
		echo '</tr>';
	}
	echo '</table>';

	//Se llama a datosCancion para imprimir la información de las canciones que contiene ese album específico 
	//se le pasa el código 
	datosCancion($album->getCod());
}

//Recoge el codigo de datosDisco 
function datosCancion($cod)
{ //devuelve los datos de todas las canciones del album pasado
	$conectar = new Conexion('localhost', 'root', '', 'discografia');
	$conexion = $conectar->conectionPDO();
	//Consulta que devuele todos los campos de canción donde el album tiene el codigo pasado
	$resultado = $conexion->query('SELECT * FROM discografia.cancion WHERE album = ' . $cod . ';');
	//Tabla de CANCIONES DEL DISCO
	echo '<h3>CANCIONES DEL DISCO</h3>';
	echo '<table>';
	echo '<tr>
			<th>título</th>
			<th>Album</th>
			<th>posicion</th>
			<th>duracion</th>
			<th>genero</th>			
		</tr>';
	//Recorre los resultados de la consulta 
	while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)) {
		//Por cada resultado se crea un nuevo objeto canción (misma alternativa que en datosDisco)
		$listaCanciones = new Cancion($registro['titulo'], $registro['album'], $registro['posicion'], $registro['duracion'], $registro['genero']);
		//Imprime la tabla con los datos
		echo '<tr>';
		echo '<td>' . $listaCanciones->getTitulo() . '</td>';
		echo '<td>' . $listaCanciones->getAlbum() . '</td>';
		echo '<td>' . $listaCanciones->getPosicion() . '</td>';
		echo '<td>' . $listaCanciones->getDuracion() . '</td>';
		echo '<td>' . $listaCanciones->getGenero() . '</td>';
		echo '</tr>';
	}
	echo '</table>';
}

function datosBuscados($textoBuscar, $select, $genero)
{
	//Conectar a la base de datos
	$conectar = new Conexion('localhost', 'root', '', 'discografia');
	$conexion = $conectar->conectionPDO();

	//Consulta preparada para contar resultados 
	$sql = "SELECT COUNT(*) as total 
            FROM discografia.cancion, discografia.album 
            WHERE album.codigo = cancion.album 
            AND cancion.genero = :genero 
            AND $select LIKE :textoBuscar";

	$stmt = $conexion->prepare($sql);
	$stmt->execute([':genero' => $genero, ':textoBuscar' => "%$textoBuscar%"]);

	//Saca la cantidad de resultados (canciones) encontradas
	$resultado = $stmt->fetch(PDO::FETCH_ASSOC);
	$totalCanciones = $resultado['total']; //as total

	//Si no hay resultados, mostrar mensaje informando
	if ($totalCanciones == 0) {
		echo '<h1>NO SE ENCONTRARON RESULTADOS!</h1>';
		return; //Salir de la función
	}

	//Consulta para obtener las canciones encontradas
	$sql2 = "SELECT cancion.titulo as titulo, 
                    album.titulo as album, 
                    cancion.posicion, 
                    cancion.duracion, 
                    cancion.genero 
             FROM discografia.cancion, discografia.album 
             WHERE album.codigo = cancion.album 
             AND cancion.genero = :genero 
             AND $select LIKE :textoBuscar";

	$stmt2 = $conexion->prepare($sql2);
	$stmt2->execute([
		':genero' => $genero,
		':textoBuscar' => "%$textoBuscar%"
	]);

	//Mostrar resultados en tabla
	echo '<table>
            <tr>
                <th>Título</th>
                <th>Álbum</th>
                <th>Posición</th>
                <th>Duración</th>
                <th>Género</th>
            </tr>';

	//Recorremos los datos y mostramos cada campo de las canciones encontradas en la tabla
	//$cancion contiene --> array('titulo' => 'Canción 1', 'album', '1' ,....=> 'Álbum A', ...) y en
	//cada vuelta saca la siguinte canción
	while ($cancion = $stmt2->fetch(PDO::FETCH_ASSOC)) {
		echo '<tr>
                <td>' . htmlspecialchars($cancion['titulo']) . '</td>
                <td>' . htmlspecialchars($cancion['album']) . '</td>
                <td>' . htmlspecialchars($cancion['posicion']) . '</td>
                <td>' . htmlspecialchars($cancion['duracion']) . '</td>
                <td>' . htmlspecialchars($cancion['genero']) . '</td>
              </tr>';
	}

	echo '</table>';
}

 function gestionarCookieBusqueda($busqueda_nueva) {

    // Verificar si existe la cookie de búsquedas anteriores
    if (isset($_COOKIE['busquedas_cookie'])) {
        // Convertir el string de la cookie en un array (separado por comas)
        $busquedas_cookie = explode(',', $_COOKIE['busquedas_cookie']);
    } else {
        // Si no existe la cookie, crear un array vacío
        $busquedas_cookie = array();
    }
    
    // Verificar si la nueva búsqueda no está vacía y no existe ya en el array
    if ($busqueda_nueva != '' && !in_array($busqueda_nueva, $busquedas_cookie)) {
        // Añadir la nueva búsqueda al final del array
        $busquedas_cookie[] = $busqueda_nueva;
        
        // Limitar el array a un máximo de 10 búsquedas
        if (count($busquedas_cookie) > 10) {
            //Conservar solo las últimas 10 búsquedas (eliminar las más antiguas)
            $busquedas_cookie = array_slice($busquedas_cookie, -10);
        }
        
        // guardar el array convertido a string en la cookie (30 días de duración)
        setcookie('busquedas_cookie', implode(',', $busquedas_cookie), time() + (30 * 24 * 60 * 60), '/');
    }
    
    // Devolver el array de búsquedas (actualizado o no)
    return $busquedas_cookie;
}

//FUNCION ADICIONAL, MOSTRAR USUARIOS AL ROOT
function listaUsuarios(){

	$conectar = new Conexion('localhost', 'root', '', 'discografia');
	$conexion = $conectar->conectionPDO();

	$todos_usuarios = $conexion->query('SELECT id,usuario from tabla_usuarios where usuario != "admin"');
	echo '<table>';
	echo '<tr>
			<th>ID</th>
			<th>USUARIO</th>		
		 </tr>';
	
	foreach ($todos_usuarios->fetchAll() as  $usuario) {
		$id = $usuario['id'];
		echo '<tr>';
		echo '<td>' . $usuario['id'] . '</td>';
		echo "<td>" . $usuario['usuario'] . "<a href='borrarusuario.php?id=$id'> - Borrar Usuario</a> </td>";
		echo '</tr>';
	}
}

function editar($album){
    $conectar = new Conexion('localhost', 'root', '', 'discografia');
    $conexion = $conectar->conectionPDO();
    $codigo = $album->getCod();
    
    // Si se envió el formulario de actualización
    if (isset($_POST['actualizar'])) {
        try {
            $conexion->beginTransaction();
            
            $actualizar = $conexion->prepare('UPDATE album SET titulo = ?, discografica = ?, formato = ?, fechaLanzamiento = ?, fechaCompra = ?, precio = ? WHERE codigo = ?');
            
            $actualizar->execute([
                $_POST['titulo'],
                $_POST['discografia'],
                $_POST['formato'],
                $_POST['fechaLanzamiento'],
                $_POST['fechaCompra'],
                $_POST['precio'],
                $codigo
            ]);
            
            $conexion->commit();
            echo '<p style="color: green;">Disco actualizado correctamente</p>';
            echo '<button onclick="location.href=\'./index.php\'">Volver al inicio</button>';
            return;
            
        } catch (Exception $e) {
            $conexion->rollBack();
            echo '<p style="color: red;">Error al actualizar el disco: ' . $e->getMessage() . '</p>';
        }
    }
    
    // Obtener datos actuales del disco - CON VERIFICACIÓN
    $nombre = $conexion->prepare('SELECT titulo, discografica, formato, fechaLanzamiento, fechaCompra, precio from album where codigo=?');
    $nombre->execute([$codigo]);
    $resultado = $nombre->fetch(PDO::FETCH_ASSOC);
    
    // vERIFICAR si se encontró el disco
    if (!$resultado) {
        echo '<p style="color: red;">Error: No se encontró el disco con código ' . $codigo . '</p>';
        echo '<button onclick="location.href=\'./index.php\'">Volver al inicio</button>';
        return;
    }

    // Mostrar formulario de edición
    echo '<button onclick="location.href=\'./index.php\'">Volver</button>';
    echo '<h1>Editar disco</h1>';
    echo '<form action="" method="post">';
    
    //USAR VALORES POR DEFECTO SI SON NULL
    $titulo = $resultado['titulo'] ?? '';
    $discografica = $resultado['discografica'] ?? '';
    $formato = $resultado['formato'] ?? 'vinilo';
    $fechaLanzamiento = $resultado['fechaLanzamiento'] ?? '';
    $fechaCompra = $resultado['fechaCompra'] ?? '';
    $precio = $resultado['precio'] ?? 0;
    
    // Título con valor actual
    echo '<input type="text" required name="titulo" placeholder="Título" value="' . htmlspecialchars($titulo) . '"/>';
    
    // Discográfica con valor actual
    echo '<input type="text" required name="discografia" placeholder="Discografía" value="' . htmlspecialchars($discografica) . '"/>';
    
    // Formato con opción seleccionada
    echo '<label>Formato: </label>';
    echo '<select name="formato">';
    $formatos = ['vinilo', 'cd', 'dvd', 'mp3'];
    foreach ($formatos as $fmt) {
        $selected = ($formato == $fmt) ? 'selected' : '';
        echo '<option value="' . $fmt . '" ' . $selected . '>' . ucfirst($fmt) . '</option>';
    }
    echo '</select>';
    
    // Fecha Lanzamiento con valor actual
    echo '<label>Fecha Lanzamiento: </label>';
    echo '<input type="date" name="fechaLanzamiento" value="' . $fechaLanzamiento . '"/>';
    
    // Fecha Compra con valor actual
    echo '<label>Fecha Compra: </label>';
    echo '<input type="date" name="fechaCompra" value="' . $fechaCompra . '"/>';
    
    // Precio con valor actual
    echo '<input type="number" step="0.01" min="0" value="' . $precio . '" name="precio" placeholder="Precio"/>';
    
    echo '<input type="submit" name="actualizar" value="Actualizar Disco"/>';
    echo '<input type="button" value="Cancelar" onclick="location.href=\'index.php\'"/>';
    echo '</form>';
}