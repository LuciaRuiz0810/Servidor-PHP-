<?php 
require_once 'helper.php';
session_start(); 

	//Comprobación de si el usurio es admin o no
$esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

if ($esAdmin) {
    include_once('header_root.inc.php');
} else {
    include_once('header_publico.inc.php');
}
if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
    header('Location: login.php');
    exit;
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php
		include("datos.ini.php");
        include("conexion.ini.php");
        include("album.ini.php");
	?>
    <title>Document</title>
</head>
<body>
    <?php
        echo '<button  onclick=location.href="./index.php">Volver</button>';
        $conectar = new Conexion('localhost','root','','discografia');
		$conexion = $conectar->conectionPDO();

        //Recoge el codigo de datosDisco en datos.ini.php
        $album = new Album($_GET['cod'],'','','','','','');
        //$album se usará en borrarDisco como $this
        $album->borrarDisco($conexion,$_GET['TC']);
    ?>
</body>
</html>