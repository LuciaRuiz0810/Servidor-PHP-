<?php 
require_once 'helper.php';
session_start(); 
if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
    header('Location: login.php');
    exit;
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php
 //Comprobación de si el usurio es admin o no
$esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

if ($esAdmin) {
    include_once('header_root.inc.php');
} else {
    include_once('header_publico.inc.php');
}
		include("datos.ini.php");
        include("conexion.ini.php");
        include("album.ini.php");
        include("cancion.ini.php");
	?>
    <title>Document</title>
</head>
<body>
    <?php
    //Se recupera el codigo que se le ha pasado desde el enlace de la funcion DatosDiscografia()
        $album = new Album($_GET['cod'],'','','','','','');
        
        //Se pasa ese album (solo contiene el codigo) a datosDisco para que
        //saque su contenido
        datosDisco($album);
    ?>
</body>
</html>