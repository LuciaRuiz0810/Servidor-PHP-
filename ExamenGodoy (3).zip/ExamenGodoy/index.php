<?php
require_once 'helper.php';
session_start();

if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
	header('Location: login.php');
	exit;
}

//Comprobación de si el usurio es admin o no
$esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

if ($esAdmin) {
    include_once('header_root.inc.php');
} else {
    include_once('header_publico.inc.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/estilo.css" />
	<?php
	include("datos.ini.php");
	include("conexion.ini.php");
	include("album.ini.php");
	?>
</head>

<body>
	<?php

	$IdUser = $_SESSION['id_user'];
	$username =  $_SESSION['username'];

	$ruta = "img/users/{$username}";

	echo "<div style=text-align:left><img src='$ruta/{$IdUser}Small.png' alt='imgPerfil'" . '<br><h4>Bienvenid@! <span>' . $username . '</strong></h4></div>';
	echo "<a href='perfil.php'>Ver Perfil</a>";
	echo '<br><br>';
	//Imprime datosDiscografia
	datosDiscografia();

	?>

	<p><a href="logout.php">Cerrar sesión</a></p>
</body>

</html>