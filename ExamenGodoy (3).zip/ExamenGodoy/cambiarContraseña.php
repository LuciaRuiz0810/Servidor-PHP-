<?php
session_start();

if ($_SESSION['autenticado'] != true || !isset($_SESSION['autenticado'])) {
    header('Location: login.php');
    exit;
}

//Comprobación de si el usurio es admin o no
$esAdmin = (isset($_SESSION['admin']) && $_SESSION['admin'] == 'si');

if ($esAdmin) {
    include_once('header_root.inc.php');
} else {
    include_once('header_publico.inc.php');
}
include("datos.ini.php");
include("conexion.ini.php");

$conectar = new Conexion('localhost', 'root', '', 'discografia');
$conexion = $conectar->conectionPDO();

$id = $_GET['id'];

if (isset($_POST['enviar'])) {
    try {

        if ($_POST['pass_act'] !== '' && $_POST['pass'] !== '') {
            $conexion->beginTransaction();
            $buscar = $conexion->prepare('SELECT password FROM tabla_usuarios where id= ?');
            $buscar->execute([$id]);
            $resultado = $buscar->fetch();

            $contraseña_act = $_POST['pass_act'];
            $contraseña_nueva = $_POST['pass'];

            if (password_verify($contraseña_act, $resultado['password'])) {

                $contraseña_nueva = $_POST['pass'];
                $hash = password_hash($contraseña_nueva, PASSWORD_DEFAULT);

                $actualizar = $conexion->prepare('UPDATE tabla_usuarios SET password=? where id=?');

                $actualizar->execute([$hash, $id]);
                $conexion->commit();

                session_regenerate_id(true); //Actualiza el id del usuario

                header('Location: perfil.php?msg= Contraseña Actualizada Correctamente');
                exit();
            } else {
                echo '<h3 id=mal>CONTRASEÑA ACTUAL INCORRECTA!</h3>';
                 exit();
            }
        }

    } catch (Exception $e) {
        $conexion->rollBack();
        echo '<h1 id="mal">ERROR AL ACTUALIZAR LA CONTRASEÑA!</h1>';
        echo $e;
    }

} elseif (isset($_POST['cancelar'])) {
    header('Location: usuarios.php');

    exit();
} else {

    echo '<form action="#" method="post">
        <label for="pass_act">Introduce tu actual Contraseña:</label>
         <input type="password" name="pass_act" id="contraseña_a" >
        <label for="pass">Introduce tu nueva Contraseña:</label>
         <input type="password" name="pass" id="contraseña" >
        <input type="submit" value="enviar" name="enviar">
          <input type="submit" value="cancelar" name="cancelar">
    </form>';
}
