<?php
require_once 'helper.php';
session_start();

if (isset($_POST['confirmar_si'])) {
    
    session_unset();
    session_destroy();
    header('Location: registro.php');
    exit();

} elseif (isset($_POST['confirmar_no'])) {
    header('Location: index.php');
    exit();
} else {
    //SOLO mostrar el formulario si NO se ha hecho clic aún
    echo '<h1>Cerrar sesión</h1>';
    echo '<form action="" method="post">';
    echo '<h3>¿Seguro que quieres cerrar sesión?</h3>';
    echo '<button type="submit" name="confirmar_si">Sí</button>';
    echo '<button type="submit" name="confirmar_no">No</button>';
    echo '</form>';
}
